import pandas as pd
import numpy as np
import joblib
import os
from sklearn.ensemble import IsolationForest
from sklearn.svm import OneClassSVM
from sklearn.neighbors import LocalOutlierFactor
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam

# Load dataset
df = pd.read_csv("test_network_data_100.csv")

# Features and label
X = df.drop("label", axis=1)
y = df["label"]

# Identify categorical + numeric
categorical_cols = ["protocol_type"]
numeric_cols = [col for col in X.columns if col not in categorical_cols]

# Preprocessing: OneHot for categorical, scaling for numeric
preprocessor = ColumnTransformer(
    transformers=[
        ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_cols),
        ("num", StandardScaler(), numeric_cols)
    ]
)

# --- Traditional ML Models ---
isolation_forest = Pipeline([
    ("preprocessor", preprocessor),
    ("model", IsolationForest(n_estimators=100, contamination=0.1, random_state=42))
])

ocsvm = Pipeline([
    ("preprocessor", preprocessor),
    ("model", OneClassSVM(kernel="rbf", nu=0.1))
])

lof = Pipeline([
    ("preprocessor", preprocessor),
    ("model", LocalOutlierFactor(n_neighbors=20, novelty=True, contamination=0.1))
])

# Fit models
print("🚀 Training Isolation Forest...")
isolation_forest.fit(X)

print("🚀 Training One-Class SVM...")
ocsvm.fit(X)

print("🚀 Training Local Outlier Factor...")
lof.fit(X)

# --- Autoencoder (Deep Learning) ---
print("🚀 Training Autoencoder...")
X_processed = preprocessor.fit_transform(X)
X_processed = X_processed.toarray() if hasattr(X_processed, "toarray") else X_processed

input_dim = X_processed.shape[1]
autoencoder = Sequential([
    Dense(32, activation="relu", input_shape=(input_dim,)),
    Dense(16, activation="relu"),
    Dense(8, activation="relu"),
    Dense(16, activation="relu"),
    Dense(32, activation="relu"),
    Dense(input_dim, activation="linear")
])

autoencoder.compile(optimizer=Adam(learning_rate=0.001), loss="mse")
autoencoder.fit(X_processed, X_processed, epochs=10, batch_size=32, shuffle=True, verbose=0)

# --- Save Models in 'models/' folder ---
os.makedirs("models", exist_ok=True)

joblib.dump(isolation_forest, "models/isolation_forest.pkl")
joblib.dump(ocsvm, "models/ocsvm.pkl")
joblib.dump(lof, "models/lof.pkl")

# Save autoencoder WITHOUT optimizer/loss (safe mode)
autoencoder.save("models/autoencoder.keras", include_optimizer=False)

# Save column order
joblib.dump(X.columns.tolist(), "models/trained_columns.pkl")

print("✅ All models trained and saved in 'models/' folder")
