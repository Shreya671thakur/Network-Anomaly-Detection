for running it just create a virtual environment using CMD/powershell/terminal in VS code

activate the environment and install all dependencies 

run, python evaluate.py (this will show you every paramenter and accuracy of model )

then, streamlit run app.py (localhost)